from __future__ import annotations
import argparse, json, math, os, platform, random, statistics, sys, time, gc
from pathlib import Path
from time import perf_counter_ns
import numpy as np
import pandas as pd
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import roc_auc_score, average_precision_score, balanced_accuracy_score
from sklearn.model_selection import GroupShuffleSplit
import joblib
from numba import njit
from compiled_baselines import legal_candidates_jit

ROOT = Path(__file__).resolve().parent
DATA = ROOT / 'data'
OUT = ROOT / 'results'
FEATURE_NAMES = [
    'n_norm','row_norm','candidate_norm','center_distance','center_signed',
    'placed_fraction','next_domain_after','min_domain_after','mean_domain_after',
    'std_domain_after','total_domain_after','zero_domains_after','forced_domains_after',
    'next2_min_after','next3_mean_after','mean_domain_reduction','min_domain_reduction',
    'total_domain_reduction'
]


@njit(cache=True)
def _domain_count_jit(n, board, placed, target_row):
    count = 0
    for col in range(n):
        legal = True
        for pr in range(placed):
            pc = board[pr]
            if pc == col or abs(target_row-pr) == abs(pc-col):
                legal = False
                break
        if legal:
            count += 1
    return count


@njit(cache=True)
def extract_features_jit(n, board, row, candidate_col):
    before_len = n-row-1
    after_len = before_len
    before = np.empty(before_len, dtype=np.int64)
    after = np.empty(after_len, dtype=np.int64)
    for j in range(before_len):
        rr = row+1+j
        before[j] = _domain_count_jit(n, board, row, rr)
    board[row] = candidate_col
    for j in range(after_len):
        rr = row+1+j
        after[j] = _domain_count_jit(n, board, row+1, rr)
    board[row] = -1

    center=(n-1)/2.0
    scale=max(center,1.0)
    denom=max(n-1,1)
    if after_len > 0:
        mn=after[0]; total=0.0; zeros=0; forced=0
        for j in range(after_len):
            v=after[j]
            if v < mn: mn=v
            total += v
            if v == 0: zeros += 1
            if v == 1: forced += 1
        mean=total/after_len
        variance=0.0
        for j in range(after_len):
            variance += (after[j]-mean)*(after[j]-mean)
        sd=(variance/after_len)**0.5
        nextd=after[0]
        next2=after[0]
        if after_len > 1 and after[1] < next2: next2=after[1]
        upto=min(after_len,3)
        next3_sum=0.0
        for j in range(upto): next3_sum += after[j]
        next3=next3_sum/upto
    else:
        mn=0; total=0.0; mean=0.0; sd=0.0; zeros=0; forced=0
        nextd=0; next2=0; next3=0.0

    if before_len > 0:
        totalred=0.0; minred=before[0]
        for j in range(before_len):
            reduction=before[j]-after[j]
            totalred += reduction
            if reduction < minred: minred=reduction
        meanred=totalred/before_len
    else:
        totalred=0.0; minred=0.0; meanred=0.0

    out=np.empty(18,dtype=np.float32)
    out[0]=n/24.0
    out[1]=row/denom
    out[2]=candidate_col/denom
    out[3]=abs(candidate_col-center)/scale
    out[4]=(candidate_col-center)/scale
    out[5]=row/n
    out[6]=nextd/n
    out[7]=mn/n
    out[8]=mean/n
    out[9]=sd/n
    out[10]=total/(n*n)
    out[11]=zeros/n
    out[12]=forced/n
    out[13]=next2/n
    out[14]=next3/n
    out[15]=meanred/n
    out[16]=minred/n
    out[17]=totalred/(n*n)
    return out


@njit(cache=True)
def extract_feature_batch_jit(n, board, row, candidates):
    future_count=n-row-1
    base_masks=np.empty(future_count,dtype=np.int64)
    base_counts=np.empty(future_count,dtype=np.int64)
    full=(1<<n)-1
    for j in range(future_count):
        rr=row+1+j
        mask=full
        for pr in range(row):
            pc=board[pr]
            d=rr-pr
            mask &= ~(1<<pc)
            left=pc-d
            right=pc+d
            if left>=0: mask &= ~(1<<left)
            if right<n: mask &= ~(1<<right)
        base_masks[j]=mask
        count=0
        for col in range(n):
            if mask & (1<<col): count+=1
        base_counts[j]=count

    X=np.empty((len(candidates),18),dtype=np.float32)
    center=(n-1)/2.0
    scale=max(center,1.0)
    denom=max(n-1,1)
    for ci in range(len(candidates)):
        candidate_col=candidates[ci]
        mn=n; total=0.0; zeros=0; forced=0
        nextd=0; next2=n; next3_sum=0.0
        totalred=0.0; minred=n
        for j in range(future_count):
            rr=row+1+j
            d=rr-row
            attack=(1<<candidate_col)
            left=candidate_col-d
            right=candidate_col+d
            if left>=0: attack |= (1<<left)
            if right<n: attack |= (1<<right)
            after_mask=base_masks[j] & ~attack
            after_count=0
            for col in range(n):
                if after_mask & (1<<col): after_count+=1
            if after_count<mn: mn=after_count
            total += after_count
            if after_count==0: zeros+=1
            if after_count==1: forced+=1
            if j==0: nextd=after_count
            if after_count<next2 and j<2: next2=after_count
            if j<3: next3_sum += after_count
            reduction=base_counts[j]-after_count
            totalred += reduction
            if reduction<minred: minred=reduction
        if future_count>0:
            mean=total/future_count
            variance=0.0
            for j in range(future_count):
                rr=row+1+j
                d=rr-row
                attack=(1<<candidate_col)
                left=candidate_col-d; right=candidate_col+d
                if left>=0: attack |= (1<<left)
                if right<n: attack |= (1<<right)
                after_mask=base_masks[j] & ~attack
                cnt=0
                for col in range(n):
                    if after_mask & (1<<col): cnt+=1
                variance += (cnt-mean)*(cnt-mean)
            sd=(variance/future_count)**0.5
            upto=min(future_count,3)
            next3=next3_sum/upto
            meanred=totalred/future_count
        else:
            mn=0; mean=0.0; sd=0.0; nextd=0; next2=0; next3=0.0
            meanred=0.0; minred=0; totalred=0.0
        if next2==n: next2=0
        out=X[ci]
        out[0]=n/24.0; out[1]=row/denom; out[2]=candidate_col/denom
        out[3]=abs(candidate_col-center)/scale; out[4]=(candidate_col-center)/scale
        out[5]=row/n; out[6]=nextd/n; out[7]=mn/n; out[8]=mean/n
        out[9]=sd/n; out[10]=total/(n*n); out[11]=zeros/n; out[12]=forced/n
        out[13]=next2/n; out[14]=next3/n; out[15]=meanred/n
        out[16]=minred/n; out[17]=totalred/(n*n)
    return X


@njit(cache=True)
def rf_scores_jit(X, children_left, children_right, split_feature, thresholds, leaf_probs):
    n_samples=X.shape[0]
    n_trees=children_left.shape[0]
    result=np.zeros(n_samples,dtype=np.float64)
    for i in range(n_samples):
        total=0.0
        for t in range(n_trees):
            node=0
            while children_left[t,node] != -1:
                f=split_feature[t,node]
                if X[i,f] <= thresholds[t,node]:
                    node=children_left[t,node]
                else:
                    node=children_right[t,node]
            total += leaf_probs[t,node]
        result[i]=total/n_trees
    return result


def compile_forest(model):
    trees=model.estimators_
    n_trees=len(trees)
    max_nodes=max(tree.tree_.node_count for tree in trees)
    left=np.full((n_trees,max_nodes),-1,dtype=np.int32)
    right=np.full((n_trees,max_nodes),-1,dtype=np.int32)
    feature=np.full((n_trees,max_nodes),-1,dtype=np.int32)
    threshold=np.zeros((n_trees,max_nodes),dtype=np.float64)
    probs=np.zeros((n_trees,max_nodes),dtype=np.float64)
    positive=list(model.classes_).index(1)
    for ti,est in enumerate(trees):
        tree=est.tree_
        count=tree.node_count
        left[ti,:count]=tree.children_left
        right[ti,:count]=tree.children_right
        feature[ti,:count]=tree.feature
        threshold[ti,:count]=tree.threshold
        values=tree.value[:,0,:]
        probs[ti,:count]=values[:,positive]/values.sum(axis=1)
    return (left,right,feature,threshold,probs)


def predict_compiled(X, forest):
    left,right,feature,threshold,probs=forest
    return rf_scores_jit(X,left,right,feature,threshold,probs)


def domains(n:int, prefix:list[int]) -> list[int]:
    """Number of legal columns in each future row under a placed prefix."""
    result=[]
    for rr in range(len(prefix), n):
        forbidden=0
        for pr, pc in enumerate(prefix):
            d=rr-pr
            forbidden |= 1 << pc
            left=pc-d
            right=pc+d
            if left >= 0: forbidden |= 1 << left
            if right < n: forbidden |= 1 << right
        result.append(n - (forbidden & ((1<<n)-1)).bit_count())
    return result


def features(n:int, prefix:list[int], col:int) -> list[float]:
    row=len(prefix)
    before=domains(n, prefix)[1:]
    after=domains(n, prefix+[col])
    denom=max(n-1,1)
    center=(n-1)/2
    scale=max(center,1.0)
    if after:
        mn=min(after); total=sum(after); mean=total/len(after); sd=(sum((v-mean)**2 for v in after)/len(after))**0.5
        zeros=sum(v==0 for v in after); forced=sum(v==1 for v in after)
        nextd=after[0]; next2=min(after[:2]); next3=sum(after[:3])/len(after[:3])
    else:
        mn=mean=sd=total=zeros=forced=nextd=next2=next3=0
    if before and after:
        reductions=[b-a for b,a in zip(before,after)]
        totalred=sum(reductions); meanred=totalred/len(reductions); minred=min(reductions)
    else:
        meanred=minred=totalred=0
    return [
        n/24.0, row/denom, col/denom, abs(col-center)/scale,
        (col-center)/scale, row/n,
        nextd/n, mn/n, mean/n, sd/n, total/(n*n),
        zeros/n, forced/n, next2/n, next3/n,
        meanred/n, minred/n, totalred/(n*n)
    ]


def row_to_features(row) -> list[float]:
    n=int(row.n); r=int(row.row); col=int(row.candidate_col)
    prefix=[int(getattr(row, f'queen_col_{i}')) for i in range(r)]
    return features(n,prefix,col)


def make_xy(frame:pd.DataFrame):
    rows=[row_to_features(r) for r in frame.itertuples(index=False)]
    return np.asarray(rows,dtype=np.float32), frame['can_complete'].to_numpy(dtype=np.int8)


def train_model(data_dir:Path, results_dir:Path):
    tr=pd.read_csv(data_dir/'train.csv')
    va=pd.read_csv(data_dir/'validation.csv')
    Xtr,ytr=make_xy(tr); Xva,yva=make_xy(va)
    model=RandomForestClassifier(
        n_estimators=24, max_depth=7, min_samples_leaf=2,
        max_features='sqrt', class_weight='balanced_subsample',
        n_jobs=-1, random_state=2026
    )
    t0=perf_counter_ns(); model.fit(Xtr,ytr); train_ms=(perf_counter_ns()-t0)/1e6
    model.n_jobs = 1  # Avoid parallel-dispatch overhead for tiny candidate batches
    forest=compile_forest(model)
    t0=perf_counter_ns(); sklearn_probs=model.predict_proba(Xva)[:,list(model.classes_).index(1)]; val_ms=(perf_counter_ns()-t0)/1e6
    compiled_probs=predict_compiled(Xva[:64],forest)
    if not np.allclose(compiled_probs,sklearn_probs[:64],rtol=1e-6,atol=1e-7):
        raise RuntimeError('Compiled Random Forest scores do not match scikit-learn predict_proba')
    probs=sklearn_probs
    auc=float(roc_auc_score(yva,probs)); ap=float(average_precision_score(yva,probs))
    pred=(probs>=0.5).astype(int); bal=float(balanced_accuracy_score(yva,pred))
    # State-level top-1 ranking: on solvable states, did the highest score label a positive candidate?
    valcopy=va[['state_id','can_complete']].copy(); valcopy['score']=probs
    tops=valcopy.loc[valcopy.groupby('state_id')['score'].idxmax()]
    solvable_ids=set(va.loc[va.groupby('state_id')['can_complete'].transform('max')==1,'state_id'])
    top1=float(tops.loc[tops.state_id.isin(solvable_ids),'can_complete'].mean())
    metrics={
       'model':'RandomForestClassifier (compact)', 'n_estimators':24, 'max_depth':7,
       'min_samples_leaf':2, 'max_features':'sqrt', 'class_weight':'balanced_subsample',
       'training_examples':int(len(tr)), 'validation_examples':int(len(va)),
       'train_time_ms':train_ms, 'validation_predict_time_ms':val_ms,
       'validation_roc_auc':auc, 'validation_average_precision':ap,
       'compiled_inference_parity_max_abs_error':float(np.max(np.abs(compiled_probs-sklearn_probs[:64]))),
       'validation_balanced_accuracy_at_0_5':bal, 'solvable_state_top1_hit_rate':top1,
       'feature_names':FEATURE_NAMES,
       'training_board_sizes':sorted(int(x) for x in tr.n.unique()),
       'validation_board_sizes':sorted(int(x) for x in va.n.unique()),
       'note':'Training labels are inherited from the project dataset. The compact variable-size feature representation is derived from each stored partial-board/candidate example.'
    }
    results_dir.mkdir(parents=True,exist_ok=True)
    joblib.dump(model,results_dir/'compact_rf.joblib')
    (results_dir/'model_metrics.json').write_text(json.dumps(metrics,indent=2))
    return model,metrics,forest


def safe(board:list[int], row:int, col:int)->bool:
    for r,c in enumerate(board[:row]):
        if c==col or abs(row-r)==abs(col-c): return False
    return True


def recursive(n:int, fixed:dict[int,int]|None=None):
    fixed=fixed or {}; board=[-1]*n
    stats={'explored_states':0,'backtracks':0,'candidate_checks':0}
    def bt(row):
        if row==n: return True
        stats['explored_states']+=1
        choices=[fixed[row]] if row in fixed else range(n)
        for c in choices:
            stats['candidate_checks']+=1
            if safe(board,row,c):
                board[row]=c
                if bt(row+1): return True
                board[row]=-1; stats['backtracks']+=1
        return False
    ok=bt(0)
    return (board.copy() if ok else None),stats


def iterative(n:int, fixed:dict[int,int]|None=None):
    fixed=fixed or {}; board=[-1]*n; nextc=[0]*n; row=0
    st={'explored_states':1,'backtracks':0,'candidate_checks':0}
    while row>=0:
        if row==n: return board.copy(),st
        limit=nextc[row]
        choices=[fixed[row]] if row in fixed else range(limit,n)
        placed=False
        for c in choices:
            if c<nextc[row]: continue
            nextc[row]=c+1; st['candidate_checks']+=1
            if safe(board,row,c):
                board[row]=c; row+=1
                if row<n: nextc[row]=0; st['explored_states']+=1
                placed=True; break
        if placed: continue
        nextc[row]=0; row-=1
        if row>=0:
            board[row]=-1; st['backtracks']+=1
    return None,st


def ml_guided(n:int, model, forest, fixed:dict[int,int]|None=None, max_guided_depth:int|None=None):
    fixed=fixed or {}; board=np.full(n,-1,dtype=np.int64); fixed_arr=np.full(n,-1,dtype=np.int64)
    for fr,fc in fixed.items(): fixed_arr[fr]=fc
    row=0
    ranked=[None]*n; idx=[0]*n
    st={'explored_states':1,'backtracks':0,'candidate_checks':0,
        'ml_calls':0,'model_predictions':0,'feature_time_ms':0.0,'inference_time_ms':0.0}
    while row>=0:
        if row==n: return board.tolist(),st
        if ranked[row] is None:
            candidate_array,checks=legal_candidates_jit(n,board,row,fixed_arr)
            st['candidate_checks']+=int(checks)
            legal=candidate_array.tolist()
            if not legal:
                ranked[row]=[]
            elif len(legal)==1 or (max_guided_depth is not None and row >= max_guided_depth):
                # Avoid invoking a classifier when it cannot change the ordering or after the selected guidance depth.
                ranked[row]=[(c,1.0) for c in legal]
            else:
                t=perf_counter_ns()
                board_arr=np.asarray(board,dtype=np.int64)
                candidate_arr=np.asarray(legal,dtype=np.int64)
                X=extract_feature_batch_jit(n,board_arr,row,candidate_arr)
                st['feature_time_ms']+=(perf_counter_ns()-t)/1e6
                t=perf_counter_ns()
                scores=predict_compiled(X,forest)
                st['inference_time_ms']+=(perf_counter_ns()-t)/1e6
                st['ml_calls']+=1; st['model_predictions']+=len(legal)
                ranked[row]=sorted(zip(legal,scores.tolist()),key=lambda z:(-z[1],z[0]))
        if idx[row] < len(ranked[row]):
            c=ranked[row][idx[row]][0]; idx[row]+=1
            board[row]=c; row+=1
            if row<n:
                ranked[row]=None; idx[row]=0; st['explored_states']+=1
        else:
            ranked[row]=None; idx[row]=0; row-=1
            if row>=0:
                board[row]=-1; st['backtracks']+=1
    return None,st


def validate(n,sol):
    if sol is None: return n in (2,3)
    return len(sol)==n and all(0<=sol[r]<n and safe(sol,r,sol[r]) for r in range(n))


def make_fixed_cases(n:int):
    # Deterministic, valid first-row placements; same constrained instance for every solver.
    if n in (2,3): return []
    return [{'case':'first_queen_col_0','fixed':{0:0}},
            {'case':'first_queen_center','fixed':{0:n//2}}]


def benchmark(model, forest, sizes:list[int], repeats:int=10, warmups:int=2):
    solvers={'recursive':recursive,'iterative':iterative,'ml_guided':lambda n,f:ml_guided(n,model,forest,f)}
    records=[]
    for n in sizes:
        cases=[{'case':'empty_board','fixed':{}}]+make_fixed_cases(n)
        for case in cases:
            f=case['fixed']
            # Warmups and correctness checks
            for name,fn in solvers.items():
                for _ in range(warmups):
                    sol,st=fn(n,f)
                    if not validate(n,sol): raise RuntimeError(f'Incorrect {name} result N={n} {case["case"]}')
            for rep in range(1,repeats+1):
                order=list(solvers); random.Random(24000+n*100+rep).shuffle(order)
                for name in order:
                    gc.collect(); t0=perf_counter_ns(); sol,st=solvers[name](n,f); elapsed=(perf_counter_ns()-t0)/1e6
                    if not validate(n,sol): raise RuntimeError(f'Incorrect {name} result N={n} {case["case"]}')
                    records.append({'n':n,'case':case['case'],'algorithm':name,'run':rep,
                        'execution_time_ms':elapsed,'feature_time_ms':st.get('feature_time_ms',0.0),
                        'inference_time_ms':st.get('inference_time_ms',0.0),
                        'explored_states':st['explored_states'],'backtracks':st['backtracks'],
                        'candidate_checks':st['candidate_checks'],'ml_calls':st.get('ml_calls',0),
                        'model_predictions':st.get('model_predictions',0),'valid_solution':True})
            print(f'Finished N={n} / {case["case"]}')
    raw=pd.DataFrame(records)
    summary=raw.groupby(['n','case','algorithm'],as_index=False).agg(
       runs=('run','count'),median_time_ms=('execution_time_ms','median'),
       mean_time_ms=('execution_time_ms','mean'),std_time_ms=('execution_time_ms','std'),
       p25_time_ms=('execution_time_ms',lambda x:x.quantile(.25)),
       p75_time_ms=('execution_time_ms',lambda x:x.quantile(.75)),
       median_feature_ms=('feature_time_ms','median'),median_inference_ms=('inference_time_ms','median'),
       median_states=('explored_states','median'),median_backtracks=('backtracks','median'),
       median_candidate_checks=('candidate_checks','median'),valid_all=('valid_solution','all'))
    return raw,summary


def main():
    p=argparse.ArgumentParser()
    p.add_argument('--sizes',nargs='+',type=int,default=[8,10,12,14,16,20,24])
    p.add_argument('--repeats',type=int,default=10); p.add_argument('--warmups',type=int,default=2)
    a=p.parse_args()
    model,metrics,forest=train_model(DATA,OUT)
    print('MODEL METRICS',json.dumps(metrics,indent=2))
    raw,summary=benchmark(model,forest,a.sizes,a.repeats,a.warmups)
    raw.to_csv(OUT/'benchmark_runs.csv',index=False)
    summary.to_csv(OUT/'benchmark_summary.csv',index=False)
    summary['speedup_vs_recursive']=np.nan
    summary['speedup_vs_iterative']=np.nan
    for (n,case),g in summary.groupby(['n','case']):
        vals=dict(zip(g.algorithm,g.median_time_ms))
        mask=(summary.n==n)&(summary.case==case)&(summary.algorithm=='ml_guided')
        if 'recursive' in vals: summary.loc[mask,'speedup_vs_recursive']=vals['recursive']/vals['ml_guided']
        if 'iterative' in vals: summary.loc[mask,'speedup_vs_iterative']=vals['iterative']/vals['ml_guided']
    summary.to_csv(OUT/'benchmark_summary.csv',index=False)
    print('\nBENCHMARK SUMMARY')
    print(summary.to_string(index=False,float_format=lambda x:f'{x:.4f}'))
    metadata={'python':sys.version,'platform':platform.platform(),'sizes':a.sizes,'repeats':a.repeats,'warmups':a.warmups,
      'timing':'perf_counter_ns around full solver call; includes Numba-compiled feature construction and Numba execution of the exact trained Random Forest trees; model training/loading/JIT compilation excluded',
      'fixed_instances':'empty board, first queen fixed at column 0, first queen fixed at centre; identical instance per algorithm',
      'note':'This is an isolated experimental harness based on the uploaded training dataset and current solver definitions. It does not modify or push to GitHub.'}
    (OUT/'benchmark_metadata.json').write_text(json.dumps(metadata,indent=2))

if __name__=='__main__': main()
