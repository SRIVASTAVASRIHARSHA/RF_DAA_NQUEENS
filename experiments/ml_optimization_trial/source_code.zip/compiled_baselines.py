"""Numba-compiled fixed-row recursive and iterative N-Queens baselines.

They preserve the same ascending-column search order and backtracking tree
as the Python baselines, while replacing repeated row scans with column and
diagonal bit masks.
"""
import numpy as np
from numba import njit


@njit(cache=True)
def _recursive_masked(n, row, columns, diag_down, diag_up, board, stats, fixed):
    if row == n:
        return True
    stats[0] += 1
    if fixed[row] >= 0:
        start = fixed[row]
        stop = start + 1
    else:
        start = 0
        stop = n
    for col in range(start, stop):
        stats[2] += 1
        col_bit = 1 << col
        down_bit = 1 << (row - col + n - 1)
        up_bit = 1 << (row + col)
        if (columns & col_bit) == 0 and (diag_down & down_bit) == 0 and (diag_up & up_bit) == 0:
            board[row] = col
            if _recursive_masked(
                n, row + 1, columns | col_bit, diag_down | down_bit,
                diag_up | up_bit, board, stats, fixed
            ):
                return True
            board[row] = -1
            stats[1] += 1
    return False


@njit(cache=True)
def _iterative_masked(n, board, stats, fixed):
    next_col = np.zeros(n, dtype=np.int64)
    columns_at = np.zeros(n + 1, dtype=np.int64)
    down_at = np.zeros(n + 1, dtype=np.int64)
    up_at = np.zeros(n + 1, dtype=np.int64)
    row = 0
    stats[0] = 1
    while row >= 0:
        if row == n:
            return True
        has_candidate = False
        col = -1
        if fixed[row] >= 0:
            if next_col[row] == 0:
                col = fixed[row]
                next_col[row] = col + 1
                has_candidate = True
        elif next_col[row] < n:
            col = next_col[row]
            next_col[row] += 1
            has_candidate = True

        if has_candidate:
            stats[2] += 1
            col_bit = 1 << col
            down_bit = 1 << (row - col + n - 1)
            up_bit = 1 << (row + col)
            if (columns_at[row] & col_bit) == 0 and (down_at[row] & down_bit) == 0 and (up_at[row] & up_bit) == 0:
                board[row] = col
                columns_at[row + 1] = columns_at[row] | col_bit
                down_at[row + 1] = down_at[row] | down_bit
                up_at[row + 1] = up_at[row] | up_bit
                row += 1
                if row < n:
                    next_col[row] = 0
                    stats[0] += 1
                continue
        else:
            next_col[row] = 0
            row -= 1
            if row >= 0:
                board[row] = -1
                stats[1] += 1
    return False


def _fixed_array(n, fixed):
    out=np.full(n,-1,dtype=np.int64)
    if fixed:
        for row,col in fixed.items():
            if not (0 <= row < n and 0 <= col < n):
                raise ValueError('fixed queen position is outside the board')
            out[row]=col
    return out


def solve_recursive_compiled(n, fixed=None):
    fixed_arr=_fixed_array(n,fixed or {})
    board=np.full(n,-1,dtype=np.int64)
    stats=np.zeros(3,dtype=np.int64)
    found=_recursive_masked(n,0,0,0,0,board,stats,fixed_arr)
    return (board.tolist() if found else None), {
        'explored_states':int(stats[0]),'backtracks':int(stats[1]),'candidate_checks':int(stats[2])
    }


def solve_iterative_compiled(n, fixed=None):
    fixed_arr=_fixed_array(n,fixed or {})
    board=np.full(n,-1,dtype=np.int64)
    stats=np.zeros(3,dtype=np.int64)
    found=_iterative_masked(n,board,stats,fixed_arr)
    return (board.tolist() if found else None), {
        'explored_states':int(stats[0]),'backtracks':int(stats[1]),'candidate_checks':int(stats[2])
    }


@njit(cache=True)
def legal_candidates_jit(n, board, row, fixed):
    candidates=np.empty(n,dtype=np.int64)
    count=0
    checks=0
    if fixed[row] >= 0:
        start=fixed[row]
        stop=start+1
    else:
        start=0
        stop=n
    for col in range(start,stop):
        checks += 1
        legal=True
        for pr in range(row):
            pc=board[pr]
            if pc==col or abs(row-pr)==abs(pc-col):
                legal=False
                break
        if legal:
            candidates[count]=col
            count+=1
    return candidates[:count],checks
